public class Lab03_B {
    public static void main(String[] args) {

        String input = "A + B - C / D";

        int tokenCount = 0;
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            String attribute;

            switch (c) {
                case 'A':
                case 'B':
                case 'C':
                case 'D':
                    attribute = "Identifier";
                    break;
                case '+':
                case '-':
                case '/':
                    attribute = "Operator";
                    break;
                default:
                    continue;
            }

            tokenCount++;
            System.out.println("TOKEN#" + tokenCount + " " + c + " " + attribute);
        }

        System.out.println("Total number of Tokens: " + tokenCount);
    }
}