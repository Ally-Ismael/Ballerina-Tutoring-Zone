import java.util.Scanner;
import java.util.ArrayList;

class Token {
    String tokenValue;
    String tokenType;

    Token(String value, String type) {
        this.tokenValue = value;
        this.tokenType = type;
    }
}

public class Lab11_A {
    private static Scanner scanner = new Scanner(System.in);
    private static ArrayList<Token> symbolTable = new ArrayList<>();
    private static int tokenCounter = 1;

    public static void main(String[] args) {
        System.out.println("A MINI COMPILER PROJECT FOR CTE711S ===================================");
        boolean continueLoop = true;

        while (continueLoop) {
            System.out.print("ENTER NEXT STRING === #" + tokenCounter + " ");
            String inputString = scanner.nextLine();

            if (inputString.equals("99")) {
                continueLoop = false;
                break;
            }

            stage1(inputString);
            stage2(inputString);
            stage3(inputString);
            stage4(inputString);
            stage5(inputString);
            stage6(inputString);
            stage7(inputString);

            symbolTable.clear();
            tokenCounter++;
        }
    }

    private static void stage1(String inputString) {
        System.out.println("======STAGE1: COMPILER TECHNIQUES--> LEXICAL ANALYSIS-Scanner");
        System.out.println("SYMBOL TABLE COMPRISING ATTRIBUTES AND TOKENS:");

        for (int i = 0; i < inputString.length(); i++) {
            char c = inputString.charAt(i);
            if (Character.isDigit(c)) {
                StringBuilder tokenValue = new StringBuilder();
                tokenValue.append(c);
                while (i + 1 < inputString.length() && Character.isDigit(inputString.charAt(i + 1))) {
                    tokenValue.append(inputString.charAt(i + 1));
                    i++;
                }
                symbolTable.add(new Token(tokenValue.toString(), "digit"));
                System.out.println("TOKEN#" + tokenCounter + " " + tokenValue + " identifier");
                tokenCounter++;
            } else if (c == '+' || c == '-' || c == '*' || c == '/') {
                symbolTable.add(new Token(Character.toString(c), "Operator"));
                System.out.println("TOKEN#" + tokenCounter + " " + c + " Operator");
                tokenCounter++;
            } else if (c == ';') {
                symbolTable.add(new Token(Character.toString(c), "symbol"));
                System.out.println("TOKEN#" + tokenCounter + " " + c + " symbol");
                tokenCounter++;
            }
        }

        System.out.println("Total number of Tokens: " + (tokenCounter - 1));
        System.out.println("GIVEN THE GRAMMAR: E=E1 | E=E1_E2 | E=E1+E2 | E=digit | E={0,1,2,3,4,5,6,7,8,9}");
    }

    private static void stage2(String inputString) {
        System.out.println("\n======STAGE2: COMPILER TECHNIQUES--> SYNTAX ANALYSIS-Parser");
        System.out.println("GET A DERIVATION FOR : " + inputString);

        StringBuilder derivation = new StringBuilder();
        derivation.append("E");

        for (Token token : symbolTable) {
            if (token.tokenType.equals("digit")) {
                derivation.append(token.tokenValue);
            } else if (token.tokenType.equals("Operator")) {
                String operator = token.tokenValue;
                if (operator.equals("+")) {
                    derivation.append(" + E");
                } else if (operator.equals("-")) {
                    derivation.append(" - E");
                } else if (operator.equals("*")) {
                    derivation.append(" * E");
                } else if (operator.equals("/")) {
                    derivation.append(" / E");
                }
            } else if (token.tokenType.equals("symbol")) {
                derivation.append(" ;");
            }

            System.out.println(derivation.toString());
        }
    }

    private static void stage3(String inputString) {
        System.out.println("\n======STAGE3: COMPILER TECHNIQUES--> SEMANTIC ANALYSIS");
        System.out.println(
                "CONCLUSION-->This expression: " + inputString + " is Syntactically and Semantically correct_");
    }

    private static void stage4(String inputString) {
        System.out.println("_\n======STAGE4: COMPILER TECHNIQUES--> INTERMEDIATE CODE REPRESENTATION (ICR)_");
        System.out.println("_THE STRING ENTERED IS : " + inputString);
        System.out.println("The ICR is as follows:");

        int t = 1;
        int operand1 = 0, operand2 = 0;
        char operator = '+';

        for (Token token : symbolTable) {
            if (token.tokenType.equals("digit")) {
                if (operand1 == 0) {
                    operand1 = Integer.parseInt(token.tokenValue);
                } else {
                    operand2 = Integer.parseInt(token.tokenValue);
                }
            } else if (token.tokenType.equals("Operator")) {
                operator = token.tokenValue.charAt(0);
            } else if (token.tokenType.equals("symbol")) {
                int result = evaluate(operand1, operand2, operator);
                System.out.println("t" + t + "= " + operand1 + operator + operand2);
                operand1 = result;
                operand2 = 0;
                t++;
            }
        }

        System.out.println("\nCONCLUSION-->The expression was correctly generated in ICR");
    }

    private static int evaluate(int operand1, int operand2, char operator) {
        switch (operator) {
            case '+':
                return operand1 + operand2;
            case '-':
                return operand1 - operand2;
            case '*':
                return operand1 * operand2;
            case '/':
                return operand1 / operand2;
            default:
                return 0;
        }
    }

    private static void stage5(String inputString) {
        System.out.println("\n======STAGE5: CODE GENERATION (CG)");

        int t = 1;
        int operand1 = 0, operand2 = 0;
        char operator = '+';

        for (Token token : symbolTable) {
            if (token.tokenType.equals("digit")) {
                if (operand1 == 0) {
                    operand1 = Integer.parseInt(token.tokenValue);
                } else {
                    operand2 = Integer.parseInt(token.tokenValue);
                }
            } else if (token.tokenType.equals("Operator")) {
                operator = token.tokenValue.charAt(0);
            } else if (token.tokenType.equals("symbol")) {
                int result = evaluate(operand1, operand2, operator);
                System.out.println("LDA " + operand1);
                switch (operator) {
                    case '+':
                        System.out.println("ADD " + operand2);
                        break;
                    case '-':
                        System.out.println("SUB " + operand2);
                        break;
                    case '*':
                        System.out.println("MUL " + operand2);
                        break;
                    case '/':
                        System.out.println("DIV " + operand2);
                        break;
                }
                System.out.println("STR t" + t);
                operand1 = result;
                operand2 = 0;
                t++;
            }
        }
    }

    private static void stage6(String inputString) {
        System.out.println("\n======STAGE6: CODE OPTIMISATION (CO)");

        int t = 1;
        int operand1 = 0, operand2 = 0;
        char operator = '+';

        for (Token token : symbolTable) {
            if (token.tokenType.equals("digit")) {
                if (operand1 == 0) {
                    operand1 = Integer.parseInt(token.tokenValue);
                } else {
                    operand2 = Integer.parseInt(token.tokenValue);
                }
            } else if (token.tokenType.equals("Operator")) {
                operator = token.tokenValue.charAt(0);
            } else if (token.tokenType.equals("symbol")) {
                int result = evaluate(operand1, operand2, operator);
                switch (operator) {
                    case '+':
                        System.out.println("ADD t" + (t - 1) + ", " + operand1 + ", " + operand2);
                        break;
                    case '-':
                        System.out.println("SUB t" + t + ", " + operand1 + ", " + operand2);
                        break;
                    case '*':
                        System.out.println("MUL t" + t + ", " + operand1 + ", " + operand2);
                        break;
                    case '/':
                        System.out.println("DIV t" + t + ", " + operand1 + ", " + operand2);
                        break;
                }
                operand1 = result;
                operand2 = 0;
                t++;
            }
        }
    }

    private static void stage7(String inputString) {
        System.out.println("\n======STAGE7: TARGET MACHINE CODE (TMC)");

        int operand1 = 0, operand2 = 0;
        char operator = '+';

        for (Token token : symbolTable) {
            if (token.tokenType.equals("digit")) {
                if (operand1 == 0) {
                    operand1 = Integer.parseInt(token.tokenValue);
                } else {
                    operand2 = Integer.parseInt(token.tokenValue);
                }
            } else if (token.tokenType.equals("Operator")) {
                operator = token.tokenValue.charAt(0);
            } else if (token.tokenType.equals("symbol")) {
                switch (operator) {
                    case '+':
                        System.out.print("001 " + toBinary(operand1) + " 000 " + toBinary(operand2));
                        break;
                    case '-':
                        System.out.print("001 " + toBinary(operand1) + " 001 " + toBinary(operand2));
                        break;
                    case '*':
                        System.out.print("001 " + toBinary(operand1) + " 010 " + toBinary(operand2));
                        break;
                    case '/':
                        System.out.print("001 " + toBinary(operand1) + " 011 " + toBinary(operand2));
                        break;
                }
                operand1 = 0;
                operand2 = 0;
            }
        }

        System.out.println("\n======END OF COMPILATION======");
        System.out.println("THE ORIGINAL INPUT STRING IS: " + inputString);
    }

    private static String toBinary(int num) {
        // Convert integer to binary string representation
        return Integer.toBinaryString(num);
    }
}
