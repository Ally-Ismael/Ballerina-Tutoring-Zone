import java.util.Scanner;

public class Lab02_A {

    public static void main(String[] args) {
        try (Scanner input = new Scanner(System.in)) {
            System.out.print("Enter 2 Numbers separated with a space (startNo and endNo): ");
            int startNo = input.nextInt();
            int endNo = input.nextInt();

            if (startNo < 0) {
                System.out.println("startNo cannot be less than 0");
                return;
            }

            if (endNo < 0) {
                System.out.println("endNo cannot be less than 0");
                return;
            }

            if (endNo > 9) {
                System.out.println("endNo cannot be greater than 9");
                return;
            }

            if (startNo > endNo) {
                System.out.println("startNo must NOT be greater than endNo");
                return;
            }

            int sumEven = 0;
            for (int i = startNo; i <= endNo; i++) {
                if (i % 2 == 0) {
                    sumEven += i;
                }
            }

            System.out.println("Sum of Even Numbers = " + sumEven);
        }
    }
}