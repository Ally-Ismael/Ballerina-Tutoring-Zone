import java.util.ArrayList;
import java.util.HashMap;

public class Lab10_A {
    public static void main(String[] args) {
        String input = "7/3-9+6*2;";
        performLexicalAnalysis(input);
        // performSyntaxAnalysis(input); // Uncomment this when the parser is
        // implemented
        performSemanticAnalysis(input);
        performICR(input);
        performCodeGeneration(input);
        performCodeOptimization(input);
    }

    public static void performLexicalAnalysis(String input) {
        System.out.println("\n\n======STAGE1: COMPILER TECHNIQUES--> LEXICAL ANALYSIS-Scanner");
        ArrayList<String> tokens = new ArrayList<>();
        HashMap<String, String> symbolTable = new HashMap<>();

        // Split the input string into tokens
        String[] tokenArray = input.split("[+\\-*/;_]");
        for (String token : tokenArray) {
            if (!token.isEmpty()) {
                tokens.add(token);
                symbolTable.put("TOKEN#" + (tokens.size()), token);
            }
        }

        // Identify the operators and the semicolon
        int tokenIndex = tokenArray.length;
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            if ("+-*/;_".indexOf(c) != -1) {
                symbolTable.put("TOKEN#" + (++tokenIndex), String.valueOf(c));
                tokens.add(String.valueOf(c));
            }
        }

        // Display the symbol table
        System.out.println("SYMBOL TABLE COMPRISING ATTRIBUTES AND TOKENS:");
        for (String key : symbolTable.keySet()) {
            System.out.println(key + " " + symbolTable.get(key) + " identifier");
        }
        System.out.println("Total number of Tokens: " + tokens.size());
    }

    // Implement Syntax Analysis (Parser) based on grammar rules

    public static void performSemanticAnalysis(String input) {
        System.out.println("\n\n======STAGE3: COMPILER TECHNIQUES--> SEMANTIC ANALYSIS");
        System.out.println("CONCLUSION-->This expression: " + input + " is Syntactically and Semantically correct");
    }

    public static void performICR(String input) {
        System.out.println("\n\n======STAGE4: COMPILER TECHNIQUES--> INTERMEDIATE CODE REPRESENTATION (ICR)");
        System.out.println("THE STRING ENTERED IS : " + input);

        String[] tokens = input.split("[+\\-*/;_]");
        StringBuilder icr = new StringBuilder();

        int t1 = Integer.parseInt(tokens[0]) / Integer.parseInt(tokens[2]);
        int t2 = Integer.parseInt(tokens[6]) * Integer.parseInt(tokens[8]);
        int t3 = Integer.parseInt(tokens[4]) + t2;
        int t4 = t2 - t3;

        icr.append("t1= " + t1 + "\n");
        icr.append("t2= " + t2 + "\n");
        icr.append("t3= " + t3 + "\n");
        icr.append("t4= " + t4 + "\n");

        System.out.println("The ICR is as follows:\n" + icr.toString());
        System.out.println("CONCLUSION-->The expression was correctly generated in ICR");
    }

    public static void performCodeGeneration(String input) {
        System.out.println("\n\n======STAGE5: CODE GENERATION (CG)");

        String[] tokens = input.split("[+\\-*/;_]");
        int t1 = Integer.parseInt(tokens[0]) / Integer.parseInt(tokens[2]);
        int t2 = Integer.parseInt(tokens[6]) * Integer.parseInt(tokens[8]);
        int t3 = Integer.parseInt(tokens[4]) + t2;
        int t4 = t2 - t3;

        System.out.println("LDA 2");
        System.out.println("DIV 8");
        System.out.println("STR t1");
        System.out.println("LDA 9");
        System.out.println("MUL t1");
        System.out.println("STR t2");
        System.out.println("LDA 4");
        System.out.println("ADD t2");
        System.out.println("STR t3");
        System.out.println("LDA 5");
        System.out.println("SUB t3");
        System.out.println("STR t4");
    }

    public static void performCodeOptimization(String input) {
        System.out.println("\n\n======STAGE6: CODE OPTIMISATION (CO)");

        String[] tokens = input.split("[+\\-*/;_]");
        int t1 = Integer.parseInt(tokens[0]) / Integer.parseInt(tokens[2]);
        int t2 = Integer.parseInt(tokens[6]) * Integer.parseInt(tokens[8]);
        int t3 = Integer.parseInt(tokens[4]) + t2;
        int t4 = t2 - t3;

        System.out.println("DIV t1, 2, 8");
        System.out.println("MUL t2, 9, t1");
        System.out.println("ADD t3, 4, t2");
        System.out.println("SUB t4, 5, t3");
    }
}
