import java.util.Scanner;

public class Lab07_A {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean quit = false;

        while (!quit) {
            System.out.println("\nA MINI COMPILER PROJECT FOR CTE711S ===================================");
            System.out.print("ENTER NEXT STRING === #1: ");
            String input = scanner.nextLine();

            if (input.equals("99")) {
                quit = true;
                continue;
            }

            if (!input.endsWith(";")) {
                System.out.println("Error: Input must end with a semicolon (;)");
                continue;
            }

            lexicalAnalysis(input);
            syntaxAnalysis(input);
            semanticAnalysis(input);
            intermediateCodeGeneration(input);
        }

        scanner.close();
    }

    private static void lexicalAnalysis(String input) {
        System.out.println("\n======STAGE1: COMPILER TECHNIQUES--> LEXICAL ANALYSIS-Scanner");
        System.out.println("SYMBOL TABLE COMPRISING ATTRIBUTES AND TOKENS:");

        int tokenCount = 1;
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            if (Character.isDigit(c)) {
                System.out.println("TOKEN#" + tokenCount + " " + c + " identifier");
                tokenCount++;
            } else if (isOperator(c)) {
                System.out.println("TOKEN#" + tokenCount + " " + c + " Operator");
                tokenCount++;
            } else if (c == ';') {
                System.out.println("TOKEN#" + tokenCount + " " + c + " symbol");
                tokenCount++;
            }
        }

        System.out.println("\nTotal number of Tokens: " + (tokenCount - 1));
        System.out.println("\nGIVEN THE GRAMMAR: E=E1 | E=E1_E2 | E=E1+E2 | E=digit | E={0,1,2,3,4,5,6,7,8,9}");
    }

    private static boolean isOperator(char c) {
        return c == '+' || c == '-' || c == '*' || c == '/' || c == '_';
    }

    private static void syntaxAnalysis(String input) {
        System.out.println("\n======STAGE2: COMPILER TECHNIQUES--> SYNTAX ANALYSIS-Parser");
        System.out.println("GET A DERIVATION FOR : " + input);

        StringBuilder derivation = new StringBuilder("E");
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            if (Character.isDigit(c)) {
                derivation.append(c);
            } else if (isOperator(c)) {
                derivation.append("_" + c);
            }
        }

        System.out.println(derivation.toString().replaceAll("_", " ") + " ;");
    }

    private static void semanticAnalysis(String input) {
        System.out.println("\n======STAGE3: COMPILER TECHNIQUES--> SEMANTIC ANALYSIS");
        System.out.println("CONCLUSION-->This expression: " + input + " is Syntactically and Semantically correct_");
    }

    private static void intermediateCodeGeneration(String input) {
        System.out.println("\n_======STAGE4: COMPILER TECHNIQUES--> INTERMEDIATE CODE REPRESENTATION (ICR)_");
        System.out.println("_THE STRING ENTERED IS : " + input);
        System.out.println("The ICR is as follows:");

        int tempVar = 1;
        int operand1 = 0, operand2 = 0, result = 0;
        char operator = '+';

        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            if (Character.isDigit(c)) {
                if (operand1 == 0) {
                    operand1 = Character.getNumericValue(c);
                } else {
                    operand2 = Character.getNumericValue(c);
                    switch (operator) {
                        case '+':
                            result = operand1 + operand2;
                            break;
                        case '-':
                            result = operand1 - operand2;
                            break;
                        case '*':
                            result = operand1 * operand2;
                            break;
                        case '/':
                            result = operand1 / operand2;
                            break;
                    }
                    System.out.println("t" + tempVar + "= " + operand1 + operator + operand2);
                    operand1 = result;
                    operand2 = 0;
                    tempVar++;
                }
            } else if (isOperator(c)) {
                operator = c;
            }
        }

        System.out.println("\nCONCLUSION-->The expression was correctly generated in ICR");
    }
}