import java.util.Scanner;
import java.util.regex.Pattern;

public class Lab05_B {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Enter a string: ");
            String input = scanner.nextLine();

            if (input.matches("^[a-zA-Z/*\\-+]+$")) {
                checkSemanticErrors(input);
            } else {
                checkSyntaxErrors(input);
            }
        }
    }

    private static void checkSemanticErrors(String input) {
        boolean hasOperator = false;
        boolean hasTwoConsecutiveOperatorsOrIdentifiers = false;

        for (int i = 0; i < input.length() - 1; i++) {
            char curr = input.charAt(i);
            char next = input.charAt(i + 1);

            if (isOperator(curr)) {
                hasOperator = true;
            }

            if ((isOperator(curr) && isOperator(next)) || (isIdentifier(curr) && isIdentifier(next))) {
                hasTwoConsecutiveOperatorsOrIdentifiers = true;
                break;
            }
        }

        if (!hasOperator) {
            System.out.println("SEMANTIC ERROR -Invalid String! There is no operator in the String (+, /, -, *,)");
        }

        if (hasTwoConsecutiveOperatorsOrIdentifiers) {
            System.out.println(
                    "SEMANTIC ERROR- two operators (*,-,+,/) or Identifier (A to Z and a to z) cannot be written together!");
        }

        if (!hasOperator && hasTwoConsecutiveOperatorsOrIdentifiers) {
            System.out.println(
                    "CONCLUSION-->Wrong expression: " + input + " No Derivation done! PLS RE-ENTER A VALID STRING");
        } else {
            performLexicalAnalysis(input);
            performSyntaxAnalysis(input);
            performSemanticAnalysis(input);
        }
    }

    private static void checkSyntaxErrors(String input) {
        boolean hasNumbers = Pattern.matches(".*\\d.*", input);
        boolean hasSpecialChars = Pattern.matches(".*[^a-zA-Z/*\\-+].*", input);

        if (hasNumbers) {
            System.out.println(
                    "SYNTAX ERROR- Numbers 0,1 to 9 are not allowed. String should contain A to Z and a to z & operators +,-,*,/");
        }

        if (hasSpecialChars) {
            System.out.println("SYNTAX ERROR- Use of Special Characters ie &, &&, $, %, !, , etc, not permitted.");
        }

        if (hasNumbers || hasSpecialChars) {
            System.out.println(
                    "CONCLUSION-->Wrong expression: " + input + " No Derivation done! PLS RE-ENTER A VALID STRING");
        }
    }

    private static boolean isOperator(char c) {
        return c == '/' || c == '*' || c == '+' || c == '-';
    }

    private static boolean isIdentifier(char c) {
        return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
    }

    private static void performLexicalAnalysis(String input) {
        System.out.println("======STAGE1: COMPILER TECHNIQUES--> LEXICAL ANALYSIS-Scanner");
        System.out.println("SYMBOL TABLE COMPRISING ATTRIBUTES AND TOKENS:");

        int tokenCount = 1;
        for (char c : input.toCharArray()) {
            if (isIdentifier(c)) {
                System.out.println("TOKEN#" + tokenCount + " " + c + " identifier");
                tokenCount++;
            } else if (isOperator(c)) {
                System.out.println("TOKEN#" + tokenCount + " " + c + " Operator");
                tokenCount++;
            }
        }

        System.out.println("Total number of Tokens: " + (tokenCount - 1));
        System.out.println("GIVEN THE GRAMMAR: E=E1 | E=E1*E2 | E=E1+E2 | E=digit | E={0,1,2,3,4,5,6,7,8,9}");
    }

    private static void performSyntaxAnalysis(String input) {
        System.out.println("\n======STAGE2: COMPILER TECHNIQUES--> SYNTAX ANALYSIS-Parser");
        System.out.println("GET A DERIVATION FOR :  " + input);
        System.out.println("ASSUME:      1=A, 2=B, 3=C, 4=D, 5=E, 6=F, 7=G, 8=H, 9=I");
        System.out.println("E,D,I,H,B ARE ALL EXPRESSION");
        System.out.println("E5 STAND FOR E EXPRESSION AT NUMBER 5,");
        System.out.println("E4 STAND FOR D EXPRESSION AT NUMBER 4, ETC.");

        StringBuilder derivation = new StringBuilder();
        derivation.append("E5 - E4 + E9 * E8 / E2 ;\n");
        derivation.append("E5 - E4 + E9 * E8 / digit2 ;\n");

        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            if (isIdentifier(c)) {
                derivation.append("digit").append(c).append(" ");
            } else if (isOperator(c)) {
                derivation.append(c).append(" ");
            }
        }

        System.out.println(derivation.toString());
    }

    private static void performSemanticAnalysis(String input) {
        System.out.println("\n======STAGE3: COMPILER TECHNIQUES--> SEMANTIC ANALYSIS");
        System.out.println("CONCLUSION-->This expression:  " + input + ";  is Syntactically and Semantically correct");
    }
}