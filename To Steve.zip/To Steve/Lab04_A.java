import java.util.Scanner;

public class Lab04_A {

    public static void main(String[] args) {

        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Enter 2 Numbers separated with space (startNo and endNo): ");
            int startNo = scanner.nextInt();
            int endNo = scanner.nextInt();

            if (startNo < 0) {
                System.out.println("startNo cannot be less than 0");
                return;
            }

            if (endNo < 0) {
                System.out.println("endNo cannot be less than 0");
                return;
            }

            if (endNo > 9) {
                System.out.println("endNo cannot be greater than 9");
                return;
            }

            if (startNo > endNo) {
                System.out.println("startNo must NOT be greater than endNo");
                return;
            }

            int sum = 0;
            for (int i = startNo; i <= endNo; i++) {
                sum += i;
            }

            System.out.println("Sum of ALL Numbers = " + sum);
        }

    }

}